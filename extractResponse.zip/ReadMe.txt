extract all the file at same location

execute the run.bat file, it will ask for starting row and end row of the response sheet

After entering row numbers, it will redirect you to validate the access of google account, just select your account and let it do it's work.

On completion of the execution, output.txt file will be created